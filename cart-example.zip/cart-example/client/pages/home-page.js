const HomePageComponent = {

  template: `
    <div class="row">
      <hello class="col-12"></hello>
    </div>
  `
}