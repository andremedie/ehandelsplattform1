const AdminPageComponent = {

    template: `
    <div>
      <h1 class="col-12"></h1>
      <product-admin class="col-12"></product-admin>
    </div>
    `,
}