const LoginPageComponent = { 
    template: `
    <div class="row">
<registration></registration>

<login></login>
    </div>
`
}